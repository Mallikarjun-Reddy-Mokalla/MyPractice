package com.aapthitech.android.developers.Data;

public class ActionData {
    public String optType;
    public int imageResource1;


    public ActionData(String optType, int imageResource1 ) {
        this.optType = optType;
        this.imageResource1 = imageResource1;

    }
}


